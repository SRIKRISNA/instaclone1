
const Footer = () => {
    return (
        <>
            <div id="footer">
                <p style={{ "textAlign": "center" }}>Designed and Developed By <a href="https://www.allwebsites.in/" style={{ "color": "antiquewhite" }}>SRIKRISHNA</a> &#169; All Rights Reserved.</p>
            </div>
        </>
    )
}
export default Footer;